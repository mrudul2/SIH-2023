
# PharmEasy Clone

This Project is Part of Challange  which has held by Masai.




## Tech Stack that are Allowed to be used / Html, JS, CSS






## Features

- All data is Obj based;
- Login / Register Defaut password ```1234``` , Name Team Titan
- Coupon Page with Filter
- Filter By Catogery
- Add to cart
- Increarse / Decrease Qty in Cart
- Delete Product From cart
- CheckOut Product/ Only When User Login Otherwise it ask to login First
- Apply Coupon At Checkout Page
- Pay By Difffrent Method UPI, Paytm , Amazon Pay , Wallet, CC/Debit.
- Purchase will show in My Order Section;

Note - All the data  purchase addtocart etc data is stored usg Local Storage only.









## Netlify Link

https://pharmeasyclone2022.netlify.app/

